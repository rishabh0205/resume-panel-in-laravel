<!DOCTYPE html>
<html lang="en">
<head>
	<link href="<?php echo e(asset('resources/assets/vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <!-- Custom styles for this template-->
    <link href="<?php echo e(asset('resources/assets/css/sb-admin-2.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('resources/assets/css/sb-admin-2.css')); ?>" rel="stylesheet">
    <script src="<?php echo e(asset('resources/assets/js/jquery_3.4.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('resources/assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- Core plugin JavaScript-->
    <script src="<?php echo e(asset('resources/assets/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>
    <!-- Custom scripts for all pages-->
    <script src="<?php echo e(asset('resources/assets/js/sb-admin-2.min.js')); ?>"></script>

	<script type="text/javascript">
		$(document).ready(function(){
			 printDiv('printableArea');
		});
		
		function printDiv(divName) {
			var printContents = document.getElementById(divName).innerHTML;
			var originalContents = document.body.innerHTML;
			document.body.innerHTML = printContents;
			window.print();
			document.body.innerHTML = originalContents;
		}
	</script>
	<style type="text/css">
		#printable { display: none; }
		@media  print
		{
			#non-printable { display: none; }
			#printable { display: block; }
		}
		@media  print{@page  {size: portrait;}}
		span.title-content {
			font-size: 1.09rem;
		}
	</style>
</head>
<body style="font-family:cambria;border:double;border-radius:5px">
	<div id="printableArea">
		<div class="container">
			<div class="row">
				<h2 class="title-content"><b><?php echo e(Auth::user()->name); ?></b></h2>
			</div>
			<table>				
				<tr>
					<td><span class="profile-content"><?php echo e(Auth::user()->address); ?></span></td>
					<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td><span class="profile-content"><b>Email :</b> <?php echo e(Auth::user()->email); ?></span></td>
				</tr>
				
				<tr>
					<td><span class="profile-content"><b>District :</b> <?php echo e(auth()->user()->district); ?>, &nbsp;<b>State :</b> <?php echo e(auth()->user()->state); ?> - <?php echo e(auth()->user()->pin); ?></span></td>
					<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td><span class="profile-content"><b>Mobile :</b> +91-<?php echo e(auth()->user()->phone_1); ?>, +91-<?php echo e(auth()->user()->phone_2); ?></span></td>
				</tr>
			</table>			

			<!-- <div class="col-md-12 col-sm-12 col-xs 12">
				<h5>Looking for challenging career so that I can use my capabilities through sincerely dedication and hard work so move up the organization</h5>
			</div> -->
			<br>
			<br>
			<br>
		</div>
	</div>
</body>
</html>

<?php /**PATH D:\xampp\htdocs\ResumePanel\resources\views/printResume.blade.php ENDPATH**/ ?>