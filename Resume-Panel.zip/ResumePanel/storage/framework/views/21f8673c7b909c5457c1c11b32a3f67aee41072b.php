<!DOCTYPE html>
<html lang="en">
<head>
	<title>User list - PDF</title>
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link href="<?php echo e(asset('resources/assets/css/sb-admin-2.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('resources/assets/css/sb-admin-2.css')); ?>" rel="stylesheet">
    <script src="<?php echo e(asset('resources/assets/js/jquery_3.4.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('resources/assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- Core plugin JavaScript-->
    <script src="<?php echo e(asset('resources/assets/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>
    <!-- Custom scripts for all pages-->
    <script src="<?php echo e(asset('resources/assets/js/sb-admin-2.min.js')); ?>"></script>
</head>
<body>
	<div class="container">
		<table class="table table-bordered">
			<thead>
				<th>Designation</th>
				<th>Company Name</th>
			</thead>
			<tbody>
				<?php $__currentLoopData = $profession; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($value->designation); ?></td>
					<td><?php echo e($value->company_name); ?></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div>
</body>
</html>

<?php /**PATH D:\xampp\htdocs\ResumePanel\resources\views/users/pdfview.blade.php ENDPATH**/ ?>