<?php $__env->startSection('page_title'); ?> Project Details | Resume Panel <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<!-- Begin Page Content -->
        <div class="container-fluid">
            <!-- Page Heading -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
                <h1 class="h4 mb-0 text-gray-800">Project Detail</h1>
                <div class="col-sm-6 col-mb-6 success-alert">
                    <div id="successMsg"></div>
                </div>
                <a href="#" data-toggle="modal" data-target="#project_modal" class="btn btn-sm btn-success shadow-sm" target="_blank"><i class="fas fa-plus fa-sm text-white-50"></i>&nbsp;&nbsp; Add</a>
            </div>

            <div class="col-xl-12 col-md-12 mb-12">
                <div class="card border-left-primary shadow h-100 py-2">
                    <div class="card-body">
            			<!-- Content Row -->
            			<table id="project_table" class=" table table-responsive table-hover">
            				<thead>
            					<tr>
            						<th>Sr No.</th>
            						<th>Project Title</th>
                                    <th>Project URL</th>
            						<th>Project Client</th>
            						<th>Description</th>
            						<th>Responsibility</th>
            						<th>Role</th>
                                    <th>Technology Used</th>
            						<th>Action</th>
            					</tr>
            				</thead>

                            <?php if(count($project) > 0): ?>
                            <tbody>
                                <?php $num = 1; ?>
                                <?php $__currentLoopData = $project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($num++); ?></td>
                                    <td><?php echo e($data->project_title); ?></td>
                                    <td><?php echo e($data->project_url); ?></td>
                                    <td><?php echo e($data->project_client); ?></td>
                                    <td><?php echo e($data->project_description); ?></td>
                                    <td><?php echo e($data->responsibility); ?></td>
                                    <td><?php echo e($data->role); ?></td>
                                    <td><?php echo e($data->technology_used); ?></td>
                                    <td> 
                                        <a href="#" data-toggle="modal" data-target="#projectEdit_modal">
                                            <img class="edit-btn" src="<?php echo e(asset('resources/assets/img/edit_icon.png')); ?>">
                                        </a>
                                        <!-- <a href="<?php echo e(Request::root()); ?>/project/delete/<?php echo e($data->id); ?>" style="cursor:pointer;" onclick="return confirm('Are you sure you want to delete..?')">
                                            <img class="delete-btn" src="<?php echo e(asset('resources/assets/img/delete_icon.png')); ?>">
                                        </a> -->
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <?php endif; ?>
            			</table>
            			<!-- Content Row -->
            		</div>
            	</div>
            </div>
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- End of Main Content -->

    <!-- Project Add Modal -->
    <div id="project_modal" class="modal fade" role="dialog">
        <div class="modal-dialog add-content-modal">
        <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Add Project Details</h4>
                    <?php if(session()->has('message')): ?>
                    <div class="col-sm-6 col-mb-6 modal-alert">
                        <div id="messageShow"><?php echo e(session()->get('message')); ?></div>
                    </div>
                    <?php endif; ?>

                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form id="projectForm" action="<?php echo e(route('submitProject')); ?>" method="post">
                <!-- <form id="projectForm" data-route="<?php echo e(route('submitProject')); ?>"> -->
                    <div class="modal-body">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="userId" id="projectUserId" value="<?php echo e(Auth::user()->id); ?>">
                        <div class="form-group row">
                            <label class="col-sm-1 col-mb-1 label-control"> Title :</label>
                            <div class="col-sm-3 col-mb-3">
                                <input type="text" class="form-control form-control-user" name="project_title" id="project_title" placeholder="Project Title">
                            </div>

                            <label class="col-sm-1 col-mb-1 label-control"> URL :</label>
                            <div class="col-sm-3 col-mb-3">
                                <input type="text" class="form-control form-control-user" name="project_url" id="project_url" placeholder="Project URL">
                            </div>

                            <label class="col-sm-1 col-mb-1 label-control"> Client :</label>
                            <div class="col-sm-3 col-mb-3">
                                <input type="text" class="form-control form-control-user" name="project_client" id="project_client" placeholder="Client Name">
                            </div>

                        </div>

                        <div class="form-group row">
                            <label class="col-sm-2 col-mb-2 label-control"> Description:</label>
                            <div class="col-sm-4 col-mb-4">
                                <textarea class="form-control form-control-user" name="description" id="description" placeholder="Project Description"></textarea>
                            </div>

                            <label class="col-sm-2 col-mb-2 label-control"> Responsibility:</label>
                            <div class="col-sm-4 col-mb-4">
                                <textarea class="form-control form-control-user" name="responsibility" id="responsibility" placeholder="Project Responsibility"></textarea>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-sm-2 col-mb-2 label-control"> Role Performed :</label>
                            <div class="col-sm-4 col-mb-4">
                                <input type="text" class="form-control form-control-user" name="role_performed" id="role_performed" placeholder="Role Performed">
                            </div>

                            <label class="col-sm-2 col-mb-2 label-control"> Technology Used :</label>
                            <div class="col-sm-4 col-mb-4">
                                <input type="text" class="form-control form-control-user" name="technology_used" id="technology_used" placeholder="Technology Used">
                            </div>
                        </div>
                    </div>
                    
                    <div class="modal-footer">
                        <div class="form-group row btn-side-right" style="margin-right:-70px;">
                            <div class="col-sm-1 col-mb-1 close-btn">
                                <input type="button" class="btn btn-secondary" value="Close" data-dismiss="modal">
                            </div>
                            <div class="col-sm-1 col-mb-1 save-btn">
                                <input type="submit" class="btn btn-primary btn-user project-save" value="Save">
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Project Add Modal End -->
    <!-- Project Delete Confirmation Modal -->
    <!-- <div id="projectDelete_modal" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <center><div class="modal-header">
                    <h4 class="modal-title">Confirmation</h4>
                </div></center>
                <div class="modal-body">
                    <center><h4>Are you sure you want to delete..?</h4></center>
                </div>
                <div class="modal-footer">
                    <div class="form-group row btn-side-right" style="margin-right:-70px;">
                        <div class="col-sm-1 col-mb-1 delete-btn">
                            <a href="<?php echo e(Request::root()); ?>/project/delete/"><button type="button" class="btn btn-primary btn-user project_delete">Delete</button></a>
                        </div>
                        <div class="col-sm-1 col-mb-1 cancel-btn">
                            <input type="button" class="btn btn-secondary" value="Cancel" data-dismiss="modal">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> -->
    <!-- Project Delete Confirmation Modal End -->

    <!-- Project Edit Form Modal -->
    <div id="projectEdit_modal" class="modal fade" role="dialog">
        <div class="modal-dialog add-content-modal">
        <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Edit Project Details</h4>
                    <?php if(session()->has('message')): ?>
                    <div class="col-sm-6 col-mb-6 modal-alert">
                        <div id="messageShow">session()->get('message')}}</div>
                    </div>
                    <?php endif; ?>

                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <form id="projectEditForm">
                    <div class="modal-body">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('PUT')); ?>

                        <input type="hidden" name="userId" id="userId" value="<?php echo e(Auth::user()->id); ?>">
                        <div class="form-group row">
                            <label class="col-sm-2 col-mb-2 label-control"> Designation :</label>
                            <div class="col-sm-4 col-mb-4">
                                <input type="text" class="form-control form-control-user" name="designation" id="designation" placeholder="Designation">
                            </div>

                            <label class="col-sm-2 col-mb-2 label-control"> Work Duration :</label>
                            <div class="col-sm-4 col-mb-4">
                                <input type="text" class="form-control form-control-user" name="time_duration" id="time_duration" placeholder="Work Duration">
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label class="col-sm-2 col-mb-2 label-control"> Company Name :</label>
                            <div class="col-sm-4 col-mb-4">
                                <textarea class="form-control form-control-user" name="company_name" id="company_name" placeholder="Company Name"></textarea>
                            </div>

                            <label class="col-sm-2 col-mb-2 label-control"> Company Address :</label>
                            <div class="col-sm-4 col-mb-4">
                                <textarea class="form-control form-control-user" name="company_address" id="company_address" placeholder="Company Address"></textarea>
                            </div>
                        </div>
                    </div>
                    
                    <div class="modal-footer">
                        <div class="form-group row btn-side-right" style="margin-right:-70px;">
                            <div class="col-sm-1 col-mb-1 close-btn">
                                <input type="button" class="btn btn-secondary" value="Close" data-dismiss="modal">
                            </div>
                            <div class="col-sm-1 col-mb-1 save-btn">
                                <input type="submit" class="btn btn-primary btn-user project-save" value="Save">
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Project Edit Form Modal -->
	<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ResumePanel\resources\views/pages/project.blade.php ENDPATH**/ ?>