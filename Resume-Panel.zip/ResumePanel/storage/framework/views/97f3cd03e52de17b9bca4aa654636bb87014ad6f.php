<!DOCTYPE html>
<html lang="en">
<head>
	<title>Generate Resume | Resume Panel</title>
	<link href="<?php echo e(asset('resources/assets/vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <!-- Custom styles for this template-->
    <link href="<?php echo e(asset('resources/assets/css/sb-admin-2.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('resources/assets/css/sb-admin-2.css')); ?>" rel="stylesheet">
    <script src="<?php echo e(asset('resources/assets/js/jquery_3.4.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('resources/assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- Core plugin JavaScript-->
    <script src="<?php echo e(asset('resources/assets/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>
    <!-- Custom scripts for all pages-->
    <script src="<?php echo e(asset('resources/assets/js/sb-admin-2.min.js')); ?>"></script>

	<script type="text/javascript">
		$(document).ready(function(){
			 printDiv('printableArea');
		});
		
		function printDiv(divName) {
			var printContents = document.getElementById(divName).innerHTML;
			var originalContents = document.body.innerHTML;
			document.body.innerHTML = printContents;
			window.print();
			document.body.innerHTML = originalContents;
		}
	</script>
	<style type="text/css">
		#printable { display: none; }
		@media  print
		{
			#non-printable { display: none; }
			#printable { display: block; }
		}
		@media  print{@page  {size: portrait;}}
		span.title-content {
			font-size: 1.09rem;
		}
	</style>
</head>
<body style="font-family:cambria;border:double;border-radius:5px">
	<div id="printableArea">
		<div class="container">
			<div class="row">
				<h2 class="title-content"><b><?php echo e(Auth::user()->name); ?></b></h2>
			</div>
			<table>				
				<tr>
					<td><span class="profile-content"><?php echo e(Auth::user()->address); ?></span></td>
					<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td><span class="profile-content"><b>Email :</b> <?php echo e(Auth::user()->email); ?></span></td>
				</tr>
				
				<tr>
					<td><span class="profile-content"><b>District :</b> <?php echo e(auth()->user()->district); ?>, &nbsp;<b>State :</b> <?php echo e(auth()->user()->state); ?> - <?php echo e(auth()->user()->pin); ?></span></td>
					<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td><span class="profile-content"><b>Mobile :</b> +91-<?php echo e(auth()->user()->phone_1); ?>, +91-<?php echo e(auth()->user()->phone_2); ?></span></td>
				</tr>
			</table>

			<hr class="divider">

			<div class="text-content">
				<p style="font-size:18px !important">Looking for challenging career so that I can use my capabilities through sincerely dedication and hard work so move up the organization.</p>
			</div>

			<table class="table table-bordered">
				<tr>
					<td style="font-weight:bold;width:30%;">PROFESSIONAL SUMMARY :</td>
				</tr>
				<tr>
					<th style="text-align:center;width:30%;vertical-align:middle;">Designation</th>
					<th style="text-align:center;width:50%;vertical-align:middle;">Company</th>
					<th style="text-align:center;width:20%;vertical-align:middle;">Duration</th>
				</tr>
				<?php if(count($profession) > 0): ?>
				<tbody>
					<?php $__currentLoopData = $profession; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td style="text-align:center;vertical-align:middle;"><?php echo e($value->designation); ?></td>
						<td style="text-align:center;vertical-align:middle;"><b><?php echo e($value->company_name); ?></b><br><?php echo e($value->company_address); ?></td>
						<td style="text-align:center;vertical-align:middle;"><?php echo e($value->time_duration); ?></td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
				<?php endif; ?>
			</table>

			<table class="table table-bordered">
				<tr>
					<td style="font-weight:bold;width:30%;">TECHNICAL SKILLS :</td>
				</tr>
				<?php if(count($technical) > 0): ?>
				<tbody>
					<?php $__currentLoopData = $technical; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<th style="text-align:left;vertical-align:middle;"><?php echo e($value->skill_title); ?></th>
						<td style="text-align:left;vertical-align:middle;"><?php echo e($value->skill_name); ?></td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
				<?php endif; ?>
			</table>

			<table class="table table-bordered">
				<tr>
					<td style="font-weight:bold;width:80%;">CERTIFICATIONS & TRAININGS :</td>
				</tr>
				<tr>
					<th style="text-align:center;width:80%;vertical-align:middle;">Certification/Training</th>
					<th style="text-align:center;width:20%;vertical-align:middle;">Year</th>
				</tr>
				<?php if(count($certification) > 0): ?>
				<tbody>
					<?php $__currentLoopData = $certification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td style="text-align:center;vertical-align:middle;"><?php echo e($value->certification_name); ?></td>
						<td style="text-align:center;vertical-align:middle;"><?php echo e($value->certification_year); ?></td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
				<?php endif; ?>
			</table>

			<table class="table table-bordered">
				<tr>
					<td style="font-weight:bold;" colspan="2">EDUCATIONAL SUMMARY :</td>
				</tr>
				<tr>
					<th style="text-align:center;vertical-align:middle;width:20%">Degree</th>
					<th style="text-align:center;vertical-align:middle;width:30%">School/College</th>
					<th style="text-align:center;vertical-align:middle;width:30%">University/Board</th>
					<th style="text-align:center;vertical-align:middle;width:10%">Year</th>
					<th style="text-align:center;vertical-align:middle;width:10%">Percentage</th>
				</tr>
				<?php if(count($educational) > 0): ?>
				<tbody>
					<?php $__currentLoopData = $educational; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td style="text-align:center;vertical-align:middle;"><?php echo e($value->degree); ?></td>
						<td style="text-align:center;vertical-align:middle;"><?php echo e($value->college); ?></td>
						<td style="text-align:center;vertical-align:middle;"><?php echo e($value->board); ?></td>
						<td style="text-align:center;vertical-align:middle;"><?php echo e($value->pass_out_year); ?></td>
						<td style="text-align:center;vertical-align:middle;"><?php echo e($value->percent); ?></td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
				<?php endif; ?>
			</table>

		<?php if(count($project) > 0): ?>
		<?php $num = 1;  ?>
		<?php $__currentLoopData = $project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<table class="table table-bordered">
				<tr>
					<th style="font-weight:bold;vertical-align:middle;font-size:1.5em" colspan="2">Project <?php echo e($num++); ?> :</th>
				</tr>
				<tr>
					<th style="font-weight:bold;vertical-align:middle;width:30%">Title :</th>
					<td style="vertical-align:middle;"><?php echo e($value->project_title); ?> 
						(<a href="<?php echo e($value->project_url); ?>"><?php echo e($value->project_url); ?></a>)</td>
				</tr>
				<tr>
					<th style="font-weight:bold;vertical-align:middle;width:30%">Client :</th>
					<td style="vertical-align:middle;"><?php echo e($value->project_client); ?> </td>
				</tr>
				<tr>
					<th style="font-weight:bold;vertical-align:middle;width:30%">Project Description :</th>
					<td style="vertical-align:middle;"><?php echo e($value->project_description); ?> </td>
				</tr>
				<tr>
					<th style="font-weight:bold;vertical-align:middle;width:30%">Responsibilities :</th>
					<td style="vertical-align:middle;"><?php echo e($value->responsibility); ?> </td>
				</tr>
				<tr>
					<th style="font-weight:bold;vertical-align:middle;width:30%">Role :</th>
					<td style="vertical-align:middle;"><?php echo e($value->role); ?> </td>
				</tr>
				<tr>
					<th style="font-weight:bold;vertical-align:middle;width:30%">Technology Used :</th>
					<td style="vertical-align:middle;"><?php echo e($value->technology_used); ?> </td>
				</tr>
			</table>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endif; ?>



			
			<br>
			<br>
			<br>
			<br>
			<br>
		</div>
	</div>
</body>
</html>

<?php /**PATH D:\xampp\htdocs\ResumePanel\resources\views/users/printResume.blade.php ENDPATH**/ ?>