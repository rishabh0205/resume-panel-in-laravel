<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProjectDetailsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('project_details', function (Blueprint $table) {
            $table->bigIncrements('id')->index();
            $table->string('user_id', 10)->index();
            $table->string('project_title', 100)->nullable();
            $table->string('project_url', 100)->nullable();
            $table->string('project_client', 50)->nullable();
            $table->string('project_description', 255)->nullable();
            $table->string('responsibility', 255)->nullable();
            $table->string('role', 100)->nullable();
            $table->string('technology_used', 100)->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('project_details');
    }
}
