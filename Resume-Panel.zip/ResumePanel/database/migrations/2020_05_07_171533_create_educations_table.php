<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateEducationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('educations', function (Blueprint $table) {
            $table->bigIncrements('id')->index();
            $table->string('user_id', 10)->index();
            $table->string('degree', 50)->nullable();
            $table->string('college', 100)->nullable();
            $table->string('board', 100)->nullable();
            $table->year('pass_out_year', 4)->nullable();
            $table->decimal('percent', 10, 2)->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('educations');
    }
}
