<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Auth::routes();
// Route::get('/home', 'HomeController@index')->name('home');
Route::get('logout', '\App\Http\Controllers\Auth\LoginController@logout');

Route::group(['Prefix' => '/'], function () {
	Route::group(['middleware' => 'auth'], function () {
		Route::get('/', 'HomeController@Index')->name('index');
		Route::get('/profile/', 'UserController@Profile')->name('profile');
		Route::put('/profile/submit/{id}', 'UserController@ProfileUpdate');


		Route::get('/professional', 'PageController@Professional')->name('professional');
		Route::post('/professional/submit', 'PageController@ProfessionalSubmit')->name('submitProfessional');
		/*Route::get('/professional/delete/{id}', 'PageController@ProfessionalDelete');*/


		Route::get('/technical', 'PageController@Technical')->name('technical');
		Route::post('/technical/submit', 'PageController@TechnicalSubmit')->name('submitTechnical');
		/*Route::get('/technical/delete/{id}', 'PageController@TechnicalDelete');*/


		Route::get('/certification', 'PageController@Certification')->name('certification');
		Route::post('/certification/submit', 'PageController@CertificationSubmit')->name('submitCertification');
		/*Route::get('/certification/delete/{id}', 'PageController@CertificationDelete');*/


		Route::get('/educational', 'PageController@Educational')->name('education');
		Route::post('/educational/submit', 'PageController@EducationalSubmit')->name('submitEducational');
		/*Route::get('/educational/delete/{id}', 'PageController@EducationalDelete');*/


		Route::get('/projects', 'PageController@Projects')->name('project');
		Route::post('/projects/submit', 'PageController@ProjectSubmit')->name('submitProject');








		Route::get('/generate/', 'HomeController@generateResume');
		// Route::get('generate-html-to-pdf', 'HomeController@generateResume')->name('generate-pdf');
		// {{ route('generate-pdf',['download'=>'pdf']) }} -- in generate resume href
	});
});

