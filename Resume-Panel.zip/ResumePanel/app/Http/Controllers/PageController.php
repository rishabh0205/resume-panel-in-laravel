<?php

namespace App\Http\Controllers;

use Auth;
use Redirect;
use Response;
use DataTables;
use App\Model\Professional;
use App\Model\TechnicalSkill;
use App\Model\Certification;
use App\Model\Educational;
use App\Model\ProjectDetail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class PageController extends Controller
{
	public function __construct()
    {
        $this->middleware('auth');
    }

    /****************************** Professional Summary Start ******************************/
    public function Professional() {
        $user_id = Auth::user()->id;
        $profession = Professional::select()->where('user_id', $user_id)->orderBy('id', 'desc')->get();
        view()->share('profession', $profession);

        return view('pages.professional');
    }

    public function ProfessionalSubmit(Request $request) {

        $message = [
            'required'  =>  "Please enter :attribute",
            'string'    =>  ":attribute must be a string",
        ];
        $rules = Validator::make($request->all(), [
            'designation'       =>  'required|string|max:50',
            'time_duration'     =>  'required|max:50',
            'company_name'      =>  'required|string|max:50',
            'company_address'   =>  'required|max:255',
        ], $message);

        if ($rules->fails()) {
            $Response = $rules->messages();
        } else {
            // $Response = ['success'=>'Your form data submitted successfully..!'];
            $professional = array(
                'user_id'           =>      $request->userId,
                'designation'       =>      ucwords($request->designation),
                'time_duration'     =>      ucwords($request->time_duration),
                'company_name'      =>      ucwords($request->company_name),
                'company_address'   =>      ucwords($request->company_address),
                'created_at'        =>      date('Y-m-d H:i:s'),
                'updated_at'        =>      date('Y-m-d H:i:s'),
            );
            Professional::insert($professional);
        }
        // return response()->json(['success'=>'Your form data submitted successfully..!'], 200);
        return redirect('/professional')->with('message', 'Your professional summary submitted successfully..!');
    }

    /*public function ProfessionalDelete($id) {
        Professional::find($id)->delete();
        // return response()->json(['success' => 'Professional deleted successfully..!']);
        return redirect('/professional')->with('message', 'Your professional summary deleted successfully..!');
    }*/
    /******************************* Professional Summary End *******************************/

    

    /****************************** Technical Skills Start ******************************/
    public function Technical() {
        $user_id = Auth::user()->id;
        $technical = TechnicalSkill::select()->where('user_id', $user_id)->get();
        view()->share('technical', $technical);

        return view('pages.technical');
    }

    public function TechnicalSubmit(Request $request) {
        $technical = array(
            'user_id'       =>      $request->userId,
            'skill_title'   =>      ucwords($request->skill_title),
            'skill_name'    =>      ucwords($request->skill_name),
            'created_at'    =>      date('Y-m-d H:i:s'),
            'updated_at'    =>      date('Y-m-d H:i:s'),
        );
        TechnicalSkill::insert($technical);
        return redirect('/technical')->with('message', 'Your technical skills submitted successfully..!');
    }

    /*public function TechnicalDelete($id) {
        TechnicalSkill::find($id)->delete();
        return redirect('/technical')->with('message', 'Your technical skills deleted successfully..!');
    }*/
    /******************************* Technical Skills End *******************************/



    /*************************** Certification & Training Start ***************************/
    public function Certification() {
        $user_id = Auth::user()->id;
        $certification = Certification::select()->where('user_id', $user_id)->get();
        view()->share('certification', $certification);

        return view('pages.certification');
    }

    public function CertificationSubmit(Request $request) {
        $certification = array(
            'user_id'               =>  $request->userId,
            'certification_name'    =>  ucwords($request->certification),
            'certification_year'    =>  $request->year,
            'created_at'            =>  date('Y-m-d H:i:s'),
            'updated_at'            =>  date('Y-m-d H:i:s'),
        );
        Certification::insert($certification);
        return redirect('/certification')->with('message', 'Your certification detail submitted successfully..!');
    }

    /*public function CertificationDelete($id) {
        Certification::find($id)->delete();
        return redirect('/certification')->with('message', 'Your certification deleted successfully..!');
    }*/
    /**************************** Certification & Training End ****************************/



    /**************************** Education Summary Start ****************************/
    public function Educational () {
        $user_id = Auth::user()->id;
        $educational = Educational::select()->where('user_id', $user_id)->orderBy('id', 'asc')->get();
        view()->share('educational', $educational);

        return view('pages.educational');
    }

    public function EducationalSubmit(Request $request) {
        $educational = array(
            'user_id'       =>  $request->userId,
            'degree'        =>  ucwords($request->degree),
            'college'       =>  ucwords($request->college),
            'board'         =>  ucwords($request->board),
            'pass_out_year' =>  $request->passout_year,
            'percent'       =>  $request->percentage,
            'created_at'    =>  date('Y-m-d H:i:s'),
            'updated_at'    =>  date('Y-m-d H:i:s'),
        );
        Educational::insert($educational);
        return redirect('/educational')->with('message', 'Your educational detail submitted successfully..!');
    }

    /*public function EducationalDelete($id) {
        Educational::find($id)->delete();
        return redirect('/educational')->with('message', 'Your educational detail deleted successfully..!');
    }*/
    /***************************** Education Summary End *****************************/



    /***************************** Project Detail Start *****************************/
    public function Projects() {
        $user_id = Auth::user()->id;
        $project = ProjectDetail::select()->where('user_id', $user_id)->orderBy('id', 'asc')->get();
        view()->share('project', $project);

        return view('pages.project');
    }

    public function ProjectSubmit(Request $request) {
        $project = array(
            'user_id'               =>  $request->userId,
            'project_title'         =>  ucwords($request->project_title),
            'project_url'           =>  $request->project_url,
            'project_client'        =>  ucwords($request->project_client),
            'project_description'   =>  ucfirst($request->description),
            'responsibility'        =>  ucfirst($request->responsibility),
            'role'                  =>  ucfirst($request->role_performed),
            'technology_used'       =>  ucfirst($request->technology_used),
            'created_at'            =>  date('Y-m-d H:i:s'),
            'updated_at'            =>  date('Y-m-d H:i:s')
        );
        ProjectDetail::insert($project);
        return redirect('/projects')->with('message','Your project details submitted successfully.!');
    }
    /***************************** Project Detail End *****************************/






}
