<?php

namespace App\Http\Controllers;

use DB;
use Hash;
use App\User as Users;
use Illuminate\Http\Request;

class UserController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function Profile() {
    	return view('users.profile');
    }
    
    public function ProfileUpdate(Request $request) {
    	$id = $request->profileId;
        $pro = Users::find($id);

        $userProfile = array(
            'name'  =>  ucwords($request->userName),
            'address'   =>  ucwords($request->userAddress),
            'phone_1' =>  $request->userPhoneOne,
            'phone_2' =>  $request->userPhoneTwo,
            'district' =>  ucwords($request->userDistrict),
            'state'   =>  ucwords($request->userState),
            'pin'   =>  ucwords($request->userPin),
        );
        $data = Users::where('id', '=',  $id)->update($userProfile);
        return $data;
    }
}
