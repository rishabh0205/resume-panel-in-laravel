<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use PDF;
use Auth;
use \App\Model\Professional;
use \App\Model\TechnicalSkill;
use App\Model\Certification;
use App\Model\Educational;
use App\Model\ProjectDetail;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function Index()
    {
        return view('index');
    }

    /*public function generateResume(Request $request) {
        $user_id = Auth::user()->id;
        $profession = Professionals::select()->where('user_id', $user_id)->orderBy('id', 'desc')->get();
        view()->share('profession', $profession);

        if($request->has('view')){
            // Set extra option
            PDF::setOptions([
                'dpi' => 150, 
                'defaultFont' => 'cambria',
                'adminUsername' => 'user',
                'adminPassword' => 'password'
            ]);
            // pass view file
            $pdf = PDF::loadView('users.printResume');
            // download pdf
            return $pdf->download('profession.pdf');
        }
        return view('users.printResume');
    }*/

    public function generateResume(Request $request) {
        $user_id = Auth::user()->id;
        $profession = Professional::select()
                        ->where('user_id', $user_id)
                        ->orderBy('id', 'desc')
                        ->get();
        view()->share('profession', $profession);


        $technical = TechnicalSkill::select()
                        ->where('user_id', $user_id)
                        ->orderBy('id', 'asc')
                        ->get();
        view()->share('technical', $technical);


        $certification = Certification::select()
                        ->where('user_id', $user_id)
                        ->orderBy('id', 'asc')
                        ->get();
        view()->share('certification', $certification);


        $educational = Educational::select()
                        ->where('user_id', $user_id)
                        ->orderBy('id', 'asc')
                        ->get();
        view()->share('educational', $educational);


        $project = ProjectDetail::select()
                        ->where('user_id', $user_id)
                        ->orderBy('id', 'asc')
                        ->get();
        view()->share('project', $project);
        
        
        return view('users.printResume');
    }
}
