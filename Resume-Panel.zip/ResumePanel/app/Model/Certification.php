<?php

namespace App\Model;

use DB;
use Eloquent;
use Illuminate\Database\Eloquent\Model;

class Certification extends Model
{
    protected $table = 'certifications';

    protected $fillable = [
    	'user_id', 'certification_name', 'certification_year'
    ];
}
