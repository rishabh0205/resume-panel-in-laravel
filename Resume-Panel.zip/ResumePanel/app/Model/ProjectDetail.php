<?php

namespace App\Model;

use DB;
use Eloquent;
use Illuminate\Database\Eloquent\Model;

class ProjectDetail extends Model
{
    protected $table = 'project_details';
    
    protected $fillable = [
    	'user_id', 'project_title', 'project_client', 'project_description', 'responsibility', 'role', 'technology_used'
    ];
}
