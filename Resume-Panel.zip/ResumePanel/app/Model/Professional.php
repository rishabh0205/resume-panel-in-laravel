<?php

namespace App\Model;

use DB;
use Eloquent;
use Illuminate\Database\Eloquent\Model;

class Professional extends Model
{
	protected $table = 'professionals';
	
	protected $fillable = [
		'user_id', 'designation', 'company_name', 'company_address', 'time_duration'
	];
}
