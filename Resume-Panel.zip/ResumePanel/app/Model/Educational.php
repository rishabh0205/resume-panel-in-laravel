<?php

namespace App\Model;

use DB;
use Eloquent;
use Illuminate\Database\Eloquent\Model;

class Educational extends Model
{
    protected $table = 'educations';

    protected $fillable = [
    	'user_id', 'degree', 'university', 'pass_out_year', 'percent'
    ];
}
