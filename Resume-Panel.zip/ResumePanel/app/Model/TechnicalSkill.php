<?php

namespace App\Model;

use DB;
use Eloquent;
use Illuminate\Database\Eloquent\Model;

class TechnicalSkill extends Model
{
    protected $table = 'technical_skills';

    protected $fillable = [
    	'user_id', 'skill_title', 'skill_name'
    ];
}
