$(document).ready( function () {
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN' : $('meta[name="csrf-token"]').attr('content')
        }
    });
    $('#profileForm').on('submit', function (event) {
        event.preventDefault();

        var profileId = $('#InputId').val();
        console.log('profile_id_show => ', profileId);
        $.ajax({
            type : "PUT",
            url  : "profile/submit/"+profileId,
            data : $('#profileForm').serialize(),

            success : function(response){
                console.log('success_profile_show => ', response);
                // location.href = "{{ url('/index') }}";
                location.reload();
            },
            error: function (msg) {
                console.log('error_profile_show => ', msg);
            }
        });
    });

    /********* professional data ajax start *********/
    // $('#professional_table').DataTable({
    //     processing: true,
    //     serverSide: true,
    //     ajax: {
    //         url     :   "{{ route('professional') }}",
    //         method  :   "GET",
    //     },
    //     columns: [
    //         { data: 'id', name: 'id' },
    //         { data: 'designation', name: 'designation' },
    //         { data: 'company_name',name: 'company_name' },
    //         { data: 'company_address', name: 'company_address' },
    //         { data: 'time_duration', name: 'time_duration' },
    //         { data: 'action', name: 'action', orderable: false },
    //     ],
    // });
    
    // $('#professionalForm').on('submit', function(event) {
    //     var route = $('#professionalForm').data('route');
    //     alert(route);
    //     event.preventDefault();
    //     $(".alert").remove();
    //     // https://www.youtube.com/watch?v=9tCEbbbB54g
        
    //     $.ajax({
    //         type    :   "POST",
    //         url     :   route,
    //         data    :   $('#professionalForm').serialize(),

    //         success : function (Response) {
    //             console.log('success_professional_show', Response);
    //             if(Response.designation) {
    //                 $('#messageShow').append('<p class="alert alert-danger">'+Response.designation+'</p>');
    //             } if(Response.time_duration) {
    //                 $('#messageShow').append('<p class="alert alert-danger">'+Response.time_duration+'</p>');
    //             } if(Response.company_name) {
    //                 $('#messageShow').append('<p class="alert alert-danger">'+Response.company_name+'</p>');
    //             } if(Response.company_address) {
    //                 $('#messageShow').append('<p class="alert alert-danger">'+Response.company_address+'</p>');
    //             } if(Response.success) {
    //                 $('#designation').val(''); $('#time_duration').val(''); $('#company_name').val(''); $('#company_address').val('');
    //                 $('#professional_modal').modal('hide');
    //                 $('#successMsg').append('<p class="alert alert-success">'+Response.success+'</p>');
    //                 setTimeout(function() {
    //                     alert('loading');
    //                     location.reload();
    //                 }, 1000);
    //             }
    //         },/*
    //         error : function (msg) {
    //             console.log('error_professional_show', msg);
    //         }*/
    //     });
    // });


});

/************************** professional delete start **************************/
// function DeleteTableSection(str, action) {
var professional_id;
$('.delete_profession').click(function(){
    professional_id = $(this).data('route');
    // alert(professional_id);
    var token = $('meta[name="csrf-token"]').attr("content");
    // alert(token);
    $('#professionalDelete_modal').modal('show');
});
$('.professional_delete').click(function() {
    alert('hello')
    $.ajax({
        url     :   "/professional/delete/"+professional_id,
        // beforeSend:function(){
        //     $('.delete-btn').css('margin-right', '75px', 'important');
        //     $('.professional_delete').text('Deleting...');
        // },
        // type    :   'GET',
        // data    :   {
        //     id  :   professional_id,
        //     _token  :   token,
        // },

        success : function(response) {
            console.log('delete-file');
            setTimeout(function(){
                $('#professionalDelete_modal').modal('hide');
            }, 2000);
        }
    });
});