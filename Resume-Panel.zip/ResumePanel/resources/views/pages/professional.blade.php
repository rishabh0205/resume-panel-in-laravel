@extends('layouts.header')
@section('page_title') Professional Summary | Resume Panel @endsection
@section('content')
	<!-- Begin Page Content -->
        <div class="container-fluid">
            <!-- Page Heading -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
                <h1 class="h4 mb-0 text-gray-800">Professional Summary</h1>
                <div class="col-sm-6 col-mb-6 success-alert">
                    <div id="successMsg"></div>
                </div>
                <a href="#" data-toggle="modal" data-target="#professional_modal" class="btn btn-sm btn-success shadow-sm" target="_blank"><i class="fas fa-plus fa-sm text-white-50"></i>&nbsp;&nbsp; Add</a>
            </div>

            <div class="col-xl-12 col-md-12 mb-12">
                <div class="card border-left-primary shadow h-100 py-2">
                    <div class="card-body">
            			<!-- Content Row -->
            			<table id="professional_table" class="table-responsive table-hover">
            				<thead>
            					<tr>
            						<th>Sr No.</th>
            						<th>Designation</th>
            						<th>Company Name</th>
            						<th>Company Address</th>
            						<th>Work Duration</th>
            						<th>Action</th>
            					</tr>
            				</thead>

                            @if(count($profession) > 0)
                            <tbody>
                                <?php $num = 1; ?>
                                @foreach($profession as $data)
                                <tr>
                                    <td>{{ $num++ }}</td>
                                    <td>{{ $data->designation }}</td>
                                    <td>{{ $data->company_name }}</td>
                                    <td>{{ $data->company_address }}</td>
                                    <td>{{ $data->time_duration }}</td>
                                    <td> 
                                        <a href="#" data-toggle="modal" data-target="#professionalEdit_modal">
                                            <img class="edit-btn" src="{{ asset('resources/assets/img/edit_icon.png') }}">
                                        </a>
                                        <!-- <a href="{{ Request::root()}}/professional/delete/{{ $data->id }}" style="cursor:pointer;" onclick="return confirm('Are you sure you want to delete..?')">
                                            <img class="delete-btn" src="{{ asset('resources/assets/img/delete_icon.png') }}">
                                        </a> -->
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                            @endif
            			</table>
            			<!-- Content Row -->
            		</div>
            	</div>
            </div>
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- End of Main Content -->

    <!-- Professional Add Modal -->
    <div id="professional_modal" class="modal fade" role="dialog">
        <div class="modal-dialog add-content-modal">
        <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Add Professional Summary</h4>
                    @if(session()->has('message'))
                    <div class="col-sm-6 col-mb-6 modal-alert">
                        <div id="messageShow">session()->get('message')}}</div>
                    </div>
                    @endif

                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form id="professionalForm" action="{{ route('submitProfessional') }}" method="post">
                <!-- <form id="professionalForm" data-route="{{ route('submitProfessional') }}"> -->
                    <div class="modal-body">
                        {{ csrf_field() }}
                        <input type="hidden" name="userId" id="userId" value="{{ Auth::user()->id }}">
                        <div class="form-group row">
                            <label class="col-sm-2 col-mb-2 label-control"> Designation :</label>
                            <div class="col-sm-4 col-mb-4">
                                <input type="text" class="form-control form-control-user" name="designation" id="designation" placeholder="Designation">
                            </div>

                            <label class="col-sm-2 col-mb-2 label-control"> Work Duration :</label>
                            <div class="col-sm-4 col-mb-4">
                                <input type="text" class="form-control form-control-user" name="time_duration" id="time_duration" placeholder="Work Duration">
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label class="col-sm-2 col-mb-2 label-control"> Company Name :</label>
                            <div class="col-sm-4 col-mb-4">
                                <textarea class="form-control form-control-user" name="company_name" id="company_name" placeholder="Company Name"></textarea>
                            </div>

                            <label class="col-sm-2 col-mb-2 label-control"> Company Address :</label>
                            <div class="col-sm-4 col-mb-4">
                                <textarea class="form-control form-control-user" name="company_address" id="company_address" placeholder="Company Address"></textarea>
                            </div>
                        </div>
                    </div>
                    
                    <div class="modal-footer">
                        <div class="form-group row btn-side-right" style="margin-right:-70px;">
                            <div class="col-sm-1 col-mb-1 close-btn">
                                <input type="button" class="btn btn-secondary" value="Close" data-dismiss="modal">
                            </div>
                            <div class="col-sm-1 col-mb-1 save-btn">
                                <input type="submit" class="btn btn-primary btn-user professional-save" value="Save">
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Professional Add Modal End -->
    <!-- Professional Delete Confirmation Modal -->
    <!-- <div id="professionalDelete_modal" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <center><div class="modal-header">
                    <h4 class="modal-title">Confirmation</h4>
                </div></center>
                <div class="modal-body">
                    <center><h4>Are you sure you want to delete..?</h4></center>
                </div>
                <div class="modal-footer">
                    <div class="form-group row btn-side-right" style="margin-right:-70px;">
                        <div class="col-sm-1 col-mb-1 delete-btn">
                            <a href="{{ Request::root()}}/professional/delete/"><button type="button" class="btn btn-primary btn-user professional_delete">Delete</button></a>
                        </div>
                        <div class="col-sm-1 col-mb-1 cancel-btn">
                            <input type="button" class="btn btn-secondary" value="Cancel" data-dismiss="modal">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> -->
    <!-- Professional Delete Confirmation Modal End -->

    <!-- Professional Edit Form Modal -->
    <div id="professionalEdit_modal" class="modal fade" role="dialog">
        <div class="modal-dialog add-content-modal">
        <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Edit Professional Summary</h4>
                    @if(session()->has('message'))
                    <div class="col-sm-6 col-mb-6 modal-alert">
                        <div id="messageShow">session()->get('message')}}</div>
                    </div>
                    @endif

                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <form id="professionalEditForm">
                    <div class="modal-body">
                        {{ csrf_field() }}
                        {{ method_field('PUT') }}
                        <input type="hidden" name="userId" id="userId" value="{{ Auth::user()->id }}">
                        <div class="form-group row">
                            <label class="col-sm-2 col-mb-2 label-control"> Designation :</label>
                            <div class="col-sm-4 col-mb-4">
                                <input type="text" class="form-control form-control-user" name="designation" id="designation" placeholder="Designation">
                            </div>

                            <label class="col-sm-2 col-mb-2 label-control"> Work Duration :</label>
                            <div class="col-sm-4 col-mb-4">
                                <input type="text" class="form-control form-control-user" name="time_duration" id="time_duration" placeholder="Work Duration">
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label class="col-sm-2 col-mb-2 label-control"> Company Name :</label>
                            <div class="col-sm-4 col-mb-4">
                                <textarea class="form-control form-control-user" name="company_name" id="company_name" placeholder="Company Name"></textarea>
                            </div>

                            <label class="col-sm-2 col-mb-2 label-control"> Company Address :</label>
                            <div class="col-sm-4 col-mb-4">
                                <textarea class="form-control form-control-user" name="company_address" id="company_address" placeholder="Company Address"></textarea>
                            </div>
                        </div>
                    </div>
                    
                    <div class="modal-footer">
                        <div class="form-group row btn-side-right" style="margin-right:-70px;">
                            <div class="col-sm-1 col-mb-1 close-btn">
                                <input type="button" class="btn btn-secondary" value="Close" data-dismiss="modal">
                            </div>
                            <div class="col-sm-1 col-mb-1 save-btn">
                                <input type="submit" class="btn btn-primary btn-user professional-save" value="Save">
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Professional Edit Form Modal -->
	@include('layouts.footer')
@endsection