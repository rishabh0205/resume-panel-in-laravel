@extends('layouts.header')
@section('page_title') Educational Summary | Resume Panel @endsection
@section('content')
	<!-- Begin Page Content -->
        <div class="container-fluid">
            <!-- Page Heading -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
                <h1 class="h4 mb-0 text-gray-800">Education Summary</h1>
                <div class="col-sm-6 col-mb-6 success-alert">
                    <div id="successMsg"></div>
                </div>
                <a href="#" data-toggle="modal" data-target="#educational_modal" class="btn btn-sm btn-success shadow-sm" target="_blank"><i class="fas fa-plus fa-sm text-white-50"></i>&nbsp;&nbsp; Add</a>
            </div>

            <div class="col-xl-12 col-md-12 mb-12">
                <div class="card border-left-primary shadow h-100 py-2">
                    <div class="card-body">
            			<!-- Content Row -->
            			<table id="educational_table" class=" table table-responsive table-hover">
            				<thead>
            					<tr>
            						<th>Sr No.</th>
            						<th>Degree</th>
            						<th>College</th>
            						<th>Board</th>
            						<th>Pass-Out Year</th>
            						<th>Percentage</th>
            						<th>Action</th>
            					</tr>
            				</thead>

                            @if(count($educational) > 0)
                            <tbody>
                                <?php $num = 1; ?>
                                @foreach($educational as $data)
                                <tr>
                                    <td>{{ $num++ }}</td>
                                    <td>{{ $data->degree }}</td>
                                    <td>{{ $data->college }}</td>
                                    <td>{{ $data->board }}</td>
                                    <td>{{ $data->pass_out_year }}</td>
                                    <td>{{ $data->percent }}</td>
                                    <td> 
                                        <a href="#" data-toggle="modal" data-target="#educationalEdit_modal">
                                            <img class="edit-btn" src="{{ asset('resources/assets/img/edit_icon.png') }}">
                                        </a>
                                        <!-- <a href="{{ Request::root()}}/educational/delete/{{ $data->id }}" style="cursor:pointer;" onclick="return confirm('Are you sure you want to delete..?')">
                                            <img class="delete-btn" src="{{ asset('resources/assets/img/delete_icon.png') }}">
                                        </a> -->
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                            @endif
            			</table>
            			<!-- Content Row -->
            		</div>
            	</div>
            </div>
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- End of Main Content -->

    <!-- Educational Add Modal -->
    <div id="educational_modal" class="modal fade" role="dialog">
        <div class="modal-dialog add-content-modal">
        <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Add Educational Summary</h4>
                    @if(session()->has('message'))
                    <div class="col-sm-6 col-mb-6 modal-alert">
                        <div id="messageShow">session()->get('message')}}</div>
                    </div>
                    @endif

                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form id="educationalForm" action="{{ route('submitEducational') }}" method="post">
                <!-- <form id="educationalForm" data-route="{{ route('submitEducational') }}"> -->
                    <div class="modal-body">
                        {{ csrf_field() }}
                        <input type="hidden" name="userId" id="educationalUserId" value="{{ Auth::user()->id }}">
                        <div class="form-group row">
                            <label class="col-sm-1 col-mb-1 label-control"> Degree :</label>
                            <div class="col-sm-2 col-mb-2">
                                <input type="text" class="form-control form-control-user" name="degree" id="degree" placeholder="Degree">
                            </div>

                            <label class="col-sm-2 col-mb-2 label-control"> Pass Out Year :</label>
                            <div class="col-sm-3 col-mb-3">
                                <input type="text" class="form-control form-control-user" name="passout_year" id="passout_year" placeholder="Educational Passout Year">
                            </div>

                            <label class="col-sm-1 col-mb-1 label-control"> Percent:</label>
                            <div class="col-sm-3 col-mb-3">
                                <input type="text" class="form-control form-control-user" name="percentage" id="percentage" placeholder="Educational Percentage">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-sm-2 col-mb-2 label-control"> Collage :</label>
                            <div class="col-sm-4 col-mb-4">
                                <input type="text" class="form-control form-control-user" name="college" id="college" placeholder="Educational College">
                            </div>

                            <label class="col-sm-2 col-mb-2 label-control"> Board :</label>
                            <div class="col-sm-4 col-mb-4">
                                <input type="text" class="form-control form-control-user" name="board" id="board" placeholder="Educational Board">
                            </div>
                        </div>
                    </div>
                    
                    <div class="modal-footer">
                        <div class="form-group row btn-side-right" style="margin-right:-70px;">
                            <div class="col-sm-1 col-mb-1 close-btn">
                                <input type="button" class="btn btn-secondary" value="Close" data-dismiss="modal">
                            </div>
                            <div class="col-sm-1 col-mb-1 save-btn">
                                <input type="submit" class="btn btn-primary btn-user educational-save" value="Save">
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Educational Add Modal End -->
    <!-- Educational Delete Confirmation Modal -->
    <!-- <div id="educationalDelete_modal" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <center><div class="modal-header">
                    <h4 class="modal-title">Confirmation</h4>
                </div></center>
                <div class="modal-body">
                    <center><h4>Are you sure you want to delete..?</h4></center>
                </div>
                <div class="modal-footer">
                    <div class="form-group row btn-side-right" style="margin-right:-70px;">
                        <div class="col-sm-1 col-mb-1 delete-btn">
                            <a href="{{ Request::root()}}/educational/delete/"><button type="button" class="btn btn-primary btn-user educational_delete">Delete</button></a>
                        </div>
                        <div class="col-sm-1 col-mb-1 cancel-btn">
                            <input type="button" class="btn btn-secondary" value="Cancel" data-dismiss="modal">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> -->
    <!-- Educational Delete Confirmation Modal End -->

    <!-- Educational Edit Form Modal -->
    <div id="educationalEdit_modal" class="modal fade" role="dialog">
        <div class="modal-dialog add-content-modal">
        <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Edit Educational Summary</h4>
                    @if(session()->has('message'))
                    <div class="col-sm-6 col-mb-6 modal-alert">
                        <div id="messageShow">session()->get('message')}}</div>
                    </div>
                    @endif

                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <form id="educationalEditForm">
                    <div class="modal-body">
                        {{ csrf_field() }}
                        {{ method_field('PUT') }}
                        <input type="hidden" name="userId" id="userId" value="{{ Auth::user()->id }}">
                        <div class="form-group row">
                            <label class="col-sm-2 col-mb-2 label-control"> Designation :</label>
                            <div class="col-sm-4 col-mb-4">
                                <input type="text" class="form-control form-control-user" name="designation" id="designation" placeholder="Designation">
                            </div>

                            <label class="col-sm-2 col-mb-2 label-control"> Work Duration :</label>
                            <div class="col-sm-4 col-mb-4">
                                <input type="text" class="form-control form-control-user" name="time_duration" id="time_duration" placeholder="Work Duration">
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label class="col-sm-2 col-mb-2 label-control"> Company Name :</label>
                            <div class="col-sm-4 col-mb-4">
                                <textarea class="form-control form-control-user" name="company_name" id="company_name" placeholder="Company Name"></textarea>
                            </div>

                            <label class="col-sm-2 col-mb-2 label-control"> Company Address :</label>
                            <div class="col-sm-4 col-mb-4">
                                <textarea class="form-control form-control-user" name="company_address" id="company_address" placeholder="Company Address"></textarea>
                            </div>
                        </div>
                    </div>
                    
                    <div class="modal-footer">
                        <div class="form-group row btn-side-right" style="margin-right:-70px;">
                            <div class="col-sm-1 col-mb-1 close-btn">
                                <input type="button" class="btn btn-secondary" value="Close" data-dismiss="modal">
                            </div>
                            <div class="col-sm-1 col-mb-1 save-btn">
                                <input type="submit" class="btn btn-primary btn-user educational-save" value="Save">
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Educational Edit Form Modal -->
	@include('layouts.footer')
@endsection