<!DOCTYPE html>
<html lang="en">
<head>
	<title>User list - PDF</title>
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body>
	<div class="container">
		<table class="table table-bordered">
			<thead>
				<th>Designation</th>
				<th>Company Name</th>
			</thead>
			<tbody>
				@foreach ($profession as $key => $value)
				<tr>
					<td>{{ $value->designation }}</td>
					<td>{{ $value->company_name }}</td>
				</tr>
				@endforeach
			</tbody>
		</table>
	</div>
</body>
</html>

