@extends('layouts.header')
@section('page_title') Resume Panel | Profile @endsection
@section('content')
	<!-- Begin Page Content -->
        <div class="container-fluid">
            <!-- Page Heading -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
                <h1 class="h4 mb-0 text-gray-800">Profile</h1>
                <!-- <h1 class="btn btn-warning" id="enable_edit" style="cursor:pointer">Edit</h1> -->
            </div>

            <div class="col-xl-12 col-md-12 mb-12">
                <div class="card border-left-primary shadow h-100 py-2">
                    <div class="card-body">
            			<!-- Content Row -->
		                <form id="profileForm">
		                	{{ csrf_field() }}
		                	{{ method_field('PUT') }}
		                	<input type="hidden" name="profileId" id="InputId" value="{{ Auth::user()->id }}">
		                	<div class="form-group row">
		                  		<div class="col-sm-3 col-mb-3">
		                  			<label> Name :</label>
		                    		<input type="text" class="form-control form-control-user" name="userName" id="InputName" placeholder="First Name" value="{{ Auth::user()->name }}">
		                  		</div>

		                		<div class="col-sm-3 col-mb-3">
		                  			<label> Email :</label>
		                  			<input type="email" class="form-control form-control-user" name="userEmail" id="InputEmail" placeholder="Email Address" value="{{ Auth::user()->email }}" readonly="readonly">
		                  		</div>

		                  		<div class="col-sm-3 col-mb-3">
		                  		<label> Phone One :</label>
		                    		<input type="text" class="form-control form-control-user" name="userPhoneOne" id="InputMobileOne" placeholder="Contact Number" value="{{ Auth::user()->phone_1 }}">
		                  		</div>

		                  		<div class="col-sm-3 col-mb-3">
		                  		<label> Phone Second :</label>
		                    		<input type="text" class="form-control form-control-user" name="userPhoneTwo" id="InputMobileTwo" placeholder="Contact Number" value="{{ Auth::user()->phone_2 }}">
		                  		</div>
		                	</div>
		                	
		                	<div class="form-group row">
		                  		<label class="col-sm-1 col-mb-1 label-control"> Address:</label>
		                  		<div class="col-sm-3 col-mb-3">
		                    		<textarea class="form-control form-control-user" name="userAddress" id="InputAddress" placeholder="Address" rows="3">{{ Auth::user()->address }}</textarea>
		                  		</div>

		                  		<div class="col-sm-3 col-mb-3">
		                			<label> District :</label>
		                    		<input type="text" class="form-control form-control-user" name="userDistrict" id="InputDistrict" placeholder="District" value="{{ Auth::user()->district }}">
		                  		</div>

		                  		<div class="col-sm-3 col-mb-3">
		                  			<label> State :</label>
		                    		<input type="text" class="form-control form-control-user" name="userState" id="InputState" placeholder="State" value="{{ Auth::user()->state }}">
		                  		</div>

		                  		<div class="col-sm-2 col-mb-2">
		                  			<label> Pin :</label>
		                    		<input type="text" class="form-control form-control-user" name="userPin" id="InputPin" placeholder="Pin Code" value="{{ Auth::user()->pin }}">
		                  		</div>
		                	</div>
		                	
		                	<div class="form-group row btn-side-right">
		                		<div class="col-sm-1 col-mb-1">
		                			<input type="submit" class="btn btn-primary btn-user profile-save" value="Save">
		                		</div>
		                	</div>
		              	</form>
            			<!-- Content Row -->
            		</div>
            	</div>
            </div>
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- End of Main Content -->
	@include('layouts.footer')
@endsection