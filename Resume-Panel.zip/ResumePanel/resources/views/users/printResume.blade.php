<!DOCTYPE html>
<html lang="en">
<head>
	<title>Generate Resume | Resume Panel</title>
	<link href="{{ asset('resources/assets/vendor/fontawesome-free/css/all.min.css') }}" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <!-- Custom styles for this template-->
    <link href="{{ asset('resources/assets/css/sb-admin-2.min.css') }}" rel="stylesheet">
    <link href="{{ asset('resources/assets/css/sb-admin-2.css') }}" rel="stylesheet">
    <script src="{{ asset('resources/assets/js/jquery_3.4.1.min.js') }}"></script>
    <script src="{{ asset('resources/assets/vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
    <!-- Core plugin JavaScript-->
    <script src="{{ asset('resources/assets/vendor/jquery-easing/jquery.easing.min.js') }}"></script>
    <!-- Custom scripts for all pages-->
    <script src="{{ asset('resources/assets/js/sb-admin-2.min.js') }}"></script>

	<script type="text/javascript">
		$(document).ready(function(){
			 printDiv('printableArea');
		});
		
		function printDiv(divName) {
			var printContents = document.getElementById(divName).innerHTML;
			var originalContents = document.body.innerHTML;
			document.body.innerHTML = printContents;
			window.print();
			document.body.innerHTML = originalContents;
		}
	</script>
	<style type="text/css">
		#printable { display: none; }
		@media print
		{
			#non-printable { display: none; }
			#printable { display: block; }
		}
		@media print{@page {size: portrait;}}
		span.title-content {
			font-size: 1.09rem;
		}
	</style>
</head>
<body style="font-family:cambria;border:double;border-radius:5px">
	<div id="printableArea">
		<div class="container">
			<div class="row">
				<h2 class="title-content"><b>{{ Auth::user()->name }}</b></h2>
			</div>
			<table>				
				<tr>
					<td><span class="profile-content">{{ Auth::user()->address }}</span></td>
					<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td><span class="profile-content"><b>Email :</b> {{ Auth::user()->email }}</span></td>
				</tr>
				
				<tr>
					<td><span class="profile-content"><b>District :</b> {{ auth()->user()->district }}, &nbsp;<b>State :</b> {{ auth()->user()->state }} - {{ auth()->user()->pin }}</span></td>
					<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
					<td><span class="profile-content"><b>Mobile :</b> +91-{{auth()->user()->phone_1}}, +91-{{auth()->user()->phone_2}}</span></td>
				</tr>
			</table>

			<hr class="divider">

			<div class="text-content">
				<p style="font-size:18px !important">Looking for challenging career so that I can use my capabilities through sincerely dedication and hard work so move up the organization.</p>
			</div>

			<table class="table table-bordered">
				<tr>
					<td style="font-weight:bold;width:30%;">PROFESSIONAL SUMMARY :</td>
				</tr>
				<tr>
					<th style="text-align:center;width:30%;vertical-align:middle;">Designation</th>
					<th style="text-align:center;width:50%;vertical-align:middle;">Company</th>
					<th style="text-align:center;width:20%;vertical-align:middle;">Duration</th>
				</tr>
				@if(count($profession) > 0)
				<tbody>
					@foreach($profession as $key => $value)
					<tr>
						<td style="text-align:center;vertical-align:middle;">{{ $value->designation }}</td>
						<td style="text-align:center;vertical-align:middle;"><b>{{ $value->company_name }}</b><br>{{ $value->company_address}}</td>
						<td style="text-align:center;vertical-align:middle;">{{ $value->time_duration }}</td>
					</tr>
					@endforeach
				</tbody>
				@endif
			</table>

			<table class="table table-bordered">
				<tr>
					<td style="font-weight:bold;width:30%;">TECHNICAL SKILLS :</td>
				</tr>
				@if(count($technical) > 0)
				<tbody>
					@foreach($technical as $key => $value)
					<tr>
						<th style="text-align:left;vertical-align:middle;">{{ $value->skill_title }}</th>
						<td style="text-align:left;vertical-align:middle;">{{ $value->skill_name }}</td>
					</tr>
					@endforeach
				</tbody>
				@endif
			</table>

			<table class="table table-bordered">
				<tr>
					<td style="font-weight:bold;width:80%;">CERTIFICATIONS & TRAININGS :</td>
				</tr>
				<tr>
					<th style="text-align:center;width:80%;vertical-align:middle;">Certification/Training</th>
					<th style="text-align:center;width:20%;vertical-align:middle;">Year</th>
				</tr>
				@if(count($certification) > 0)
				<tbody>
					@foreach($certification as $key => $value)
					<tr>
						<td style="text-align:center;vertical-align:middle;">{{ $value->certification_name }}</td>
						<td style="text-align:center;vertical-align:middle;">{{ $value->certification_year }}</td>
					</tr>
					@endforeach
				</tbody>
				@endif
			</table>

			<table class="table table-bordered">
				<tr>
					<td style="font-weight:bold;" colspan="2">EDUCATIONAL SUMMARY :</td>
				</tr>
				<tr>
					<th style="text-align:center;vertical-align:middle;width:20%">Degree</th>
					<th style="text-align:center;vertical-align:middle;width:30%">School/College</th>
					<th style="text-align:center;vertical-align:middle;width:30%">University/Board</th>
					<th style="text-align:center;vertical-align:middle;width:10%">Year</th>
					<th style="text-align:center;vertical-align:middle;width:10%">Percentage</th>
				</tr>
				@if(count($educational) > 0)
				<tbody>
					@foreach($educational as $key => $value)
					<tr>
						<td style="text-align:center;vertical-align:middle;">{{ $value->degree }}</td>
						<td style="text-align:center;vertical-align:middle;">{{ $value->college }}</td>
						<td style="text-align:center;vertical-align:middle;">{{ $value->board }}</td>
						<td style="text-align:center;vertical-align:middle;">{{ $value->pass_out_year }}</td>
						<td style="text-align:center;vertical-align:middle;">{{ $value->percent }}</td>
					</tr>
					@endforeach
				</tbody>
				@endif
			</table>

		@if(count($project) > 0)
		<?php $num = 1;  ?>
		@foreach($project as $key => $value)
			<table class="table table-bordered">
				<tr>
					<th style="font-weight:bold;vertical-align:middle;font-size:1.5em" colspan="2">Project {{ $num++ }} :</th>
				</tr>
				<tr>
					<th style="font-weight:bold;vertical-align:middle;width:30%">Title :</th>
					<td style="vertical-align:middle;">{{ $value->project_title }} 
						(<a href="{{ $value->project_url }}">{{ $value->project_url }}</a>)</td>
				</tr>
				<tr>
					<th style="font-weight:bold;vertical-align:middle;width:30%">Client :</th>
					<td style="vertical-align:middle;">{{ $value->project_client }} </td>
				</tr>
				<tr>
					<th style="font-weight:bold;vertical-align:middle;width:30%">Project Description :</th>
					<td style="vertical-align:middle;">{{ $value->project_description }} </td>
				</tr>
				<tr>
					<th style="font-weight:bold;vertical-align:middle;width:30%">Responsibilities :</th>
					<td style="vertical-align:middle;">{{ $value->responsibility }} </td>
				</tr>
				<tr>
					<th style="font-weight:bold;vertical-align:middle;width:30%">Role :</th>
					<td style="vertical-align:middle;">{{ $value->role }} </td>
				</tr>
				<tr>
					<th style="font-weight:bold;vertical-align:middle;width:30%">Technology Used :</th>
					<td style="vertical-align:middle;">{{ $value->technology_used }} </td>
				</tr>
			</table>
		@endforeach
		@endif



			
			<br>
			<br>
			<br>
			<br>
			<br>
		</div>
	</div>
</body>
</html>

